﻿namespace Somatória
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNum = new System.Windows.Forms.Label();
            this.lblMult = new System.Windows.Forms.Label();
            this.lblSoma = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.txtSoma = new System.Windows.Forms.TextBox();
            this.txtMult = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNum
            // 
            this.lblNum.AutoSize = true;
            this.lblNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblNum.Location = new System.Drawing.Point(42, 43);
            this.lblNum.Name = "lblNum";
            this.lblNum.Size = new System.Drawing.Size(58, 17);
            this.lblNum.TabIndex = 0;
            this.lblNum.Text = "Número";
            // 
            // lblMult
            // 
            this.lblMult.AutoSize = true;
            this.lblMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblMult.Location = new System.Drawing.Point(42, 90);
            this.lblMult.Name = "lblMult";
            this.lblMult.Size = new System.Drawing.Size(60, 17);
            this.lblMult.TabIndex = 1;
            this.lblMult.Text = "Múltiplo:";
            // 
            // lblSoma
            // 
            this.lblSoma.AutoSize = true;
            this.lblSoma.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lblSoma.Location = new System.Drawing.Point(42, 180);
            this.lblSoma.Name = "lblSoma";
            this.lblSoma.Size = new System.Drawing.Size(48, 17);
            this.lblSoma.TabIndex = 2;
            this.lblSoma.Text = "Soma:";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(104, 40);
            this.txtNum.MaxLength = 10;
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(127, 20);
            this.txtNum.TabIndex = 3;
            // 
            // txtSoma
            // 
            this.txtSoma.Location = new System.Drawing.Point(45, 205);
            this.txtSoma.Name = "txtSoma";
            this.txtSoma.Size = new System.Drawing.Size(215, 20);
            this.txtSoma.TabIndex = 4;
            // 
            // txtMult
            // 
            this.txtMult.Location = new System.Drawing.Point(104, 87);
            this.txtMult.Name = "txtMult";
            this.txtMult.Size = new System.Drawing.Size(127, 20);
            this.txtMult.TabIndex = 5;
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.White;
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnLimpar.Location = new System.Drawing.Point(45, 136);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 30);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Tag = "";
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.Color.White;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btnCalcular.Location = new System.Drawing.Point(185, 136);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 30);
            this.btnCalcular.TabIndex = 7;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(301, 258);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtMult);
            this.Controls.Add(this.txtSoma);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.lblSoma);
            this.Controls.Add(this.lblMult);
            this.Controls.Add(this.lblNum);
            this.Name = "Form1";
            this.Text = "Somatória";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNum;
        private System.Windows.Forms.Label lblMult;
        private System.Windows.Forms.Label lblSoma;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.TextBox txtSoma;
        private System.Windows.Forms.TextBox txtMult;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnCalcular;
    }
}

