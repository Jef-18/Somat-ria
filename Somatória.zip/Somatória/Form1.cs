﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Somatória
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            if (txtNum.Text == "")
            {
                MessageBox.Show("Informe um número!!!");
            }
            else
            {
                //declaração das variáveis
                int i, num, soma = 0, mult = 0;

                num = Convert.ToInt32(txtNum.Text);

                //inicializa o laço em 1;
                //testa a condição de parada: i <= num
                //incrementa a variavel i++
                for (i = 1; i <= num; i++)
                {
                    //verifica se i é par
                    if (i % 2 == 0)
                    {
                        //faz o somatório dos números pares
                        soma = soma + i;
                    }
                }

                for (i = 1; i <= num; i++)
                {

                    if (i % 2 == 0)
                    {
                        // multiplos
                        mult = num * soma;
                        //mult = num * i;
                    }
                }

                //apresenta o número multiplos
                txtMult.Text = mult.ToString();

                //apresenta o total da soma dos pares no txtSoma
                txtSoma.Text = soma.ToString();

            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //limpa os TextBox
            txtMult.Clear();
            txtSoma.Clear();
            txtNum.Clear();
            //coloca o foco no txtNum
            txtNum.Focus();
        }
    }
}
